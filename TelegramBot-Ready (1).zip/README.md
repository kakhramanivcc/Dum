# Telegram Bot – Avtomobil Raqam Qidiruv

Bu Telegram bot yo‘qolgan avtomobil raqamlarini topishga yordam beradi.

## Ishga tushirish

1. GitHub'ga yuklang
2. Render.com'da yangi Web Service yarating
3. Python versiyasi: `3.11`
4. Build Command: `pip install -r requirements.txt`
5. Start Command: `python bot.py`
