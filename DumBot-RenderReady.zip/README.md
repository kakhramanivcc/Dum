# Dum Bot

Bu Telegram bot Render.com orqali 24/7 ishlashi uchun tayyorlangan.

## Boshlash

1. Ushbu fayllarni GitHub'ga yuklang.
2. Render.com’da yangi Python Web Service yarating.
3. Python versiyasini 3.11 qilib belgilang.
4. Build Command: `pip install -r requirements.txt`
5. Start Command: `python bot.py` (yoki `Procfile` orqali avtomatik)

